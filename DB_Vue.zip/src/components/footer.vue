<template>
    
</template>

<script>
export default {
    name: 'footer-a'

}
</script>

<style>

</style>
